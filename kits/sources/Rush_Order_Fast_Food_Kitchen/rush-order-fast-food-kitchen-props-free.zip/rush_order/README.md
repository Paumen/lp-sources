# Rush Order: Fast Food Kitchen Props

11 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| fryer_bank | 2364 | base_center |
| griddle_station | 1228 | base_center |
| pass_shelf | 1892 | base_center |
| drive_thru | 1468 | base_center |
| soda_station | 2192 | base_center |
| shake_machine | 1828 | base_center |
| prep_table | 2068 | base_center |
| tray_rack | 1804 | base_center |
| tray_set | 792 | base_center |
| menu_board | 2656 | world_origin |
| walkin_door | 1108 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
