# House Edge: Casino Floor Props

23 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| slot_cabinet | 1848 | base_center |
| roller_stool | 488 | base_center |
| roulette_wheel | 1644 | base_center |
| roulette_table | 800 | base_center |
| big_six | 2224 | base_center |
| poker_table | 1616 | base_center |
| stanchion | 464 | base_center |
| rail_section | 600 | base_center |
| craps_table | 616 | base_center |
| chip_stack_white | 384 | base_center |
| chip_stack_red | 384 | base_center |
| chip_stack_blue | 384 | base_center |
| chip_stack_green | 384 | base_center |
| chip_stack_black | 384 | base_center |
| chip_tray | 984 | base_center |
| dealing_shoe | 208 | base_center |
| dice_pair | 352 | base_center |
| card_deck | 88 | base_center |
| card_spread | 264 | base_center |
| marquee_arrow | 920 | base_center |
| marquee_star | 884 | base_center |
| atm | 616 | base_center |
| cash_bundle | 88 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
