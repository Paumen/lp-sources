# One More Rep: Gym & Fitness Props

21 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| dumbbell_rack | 2008 | base_center |
| dumbbell_pair | 1024 | base_center |
| kb_small | 456 | base_center |
| kb_medium | 492 | base_center |
| kb_large | 524 | base_center |
| barbell_loaded | 1352 | base_center |
| plate_pair | 428 | base_center |
| plate_tree | 2044 | base_center |
| flat_bench | 264 | base_center |
| incline_bench | 264 | base_center |
| power_rack | 1200 | base_center |
| treadmill | 456 | base_center |
| spin_bike | 1624 | base_center |
| medicine_balls | 576 | base_center |
| stability_ball | 396 | base_center |
| slam_ball | 288 | base_center |
| yoga_mats | 348 | base_center |
| water_cooler | 362 | base_center |
| shaker_pair | 312 | base_center |
| chalk_bucket | 264 | base_center |
| punching_bag | 532 | world_origin |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
