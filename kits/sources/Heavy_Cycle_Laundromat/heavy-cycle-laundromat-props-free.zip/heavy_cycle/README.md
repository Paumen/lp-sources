# Heavy Cycle: Laundromat Props

16 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| washer_front | 916 | base_center |
| dryer_stack | 1508 | base_center |
| washer_top | 588 | base_center |
| folding_table | 220 | base_center |
| rolling_cart | 648 | base_center |
| laundry_basket | 280 | base_center |
| towel_stacks | 132 | base_center |
| clothes_mound | 1296 | base_center |
| jug_brand_a | 312 | base_center |
| box_brand_b | 132 | base_center |
| pod_tub | 216 | base_center |
| soap_vendor | 508 | world_origin |
| coin_changer | 332 | world_origin |
| waiting_bench | 396 | base_center |
| plastic_chair | 848 | base_center |
| wash_sign | 968 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
