# All Skate: Roller Rink Props

17 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| rink_barrier_straight | 264 | base_center |
| rink_barrier_corner | 528 | base_center |
| rink_floor_tile | 132 | base_center |
| rink_center_circle | 404 | base_center |
| disco_ball | 3480 | world_origin |
| light_bar | 2100 | world_origin |
| floor_spot | 548 | base_center |
| skate_sign | 1056 | world_origin |
| stripe_panels | 1320 | world_origin |
| exchange_window | 1204 | base_center |
| exchange_turnstile | 760 | base_center |
| skates_pair_a | 1928 | base_center |
| skates_pair_b | 1752 | base_center |
| dj_booth | 1096 | base_center |
| speaker_stack | 764 | base_center |
| locker_bank | 1672 | base_center |
| cubby_bench | 968 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
