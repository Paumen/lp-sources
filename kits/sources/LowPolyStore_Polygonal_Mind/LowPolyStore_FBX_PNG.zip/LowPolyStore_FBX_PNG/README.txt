LowPolyStore Asset Pack - slimmed version
Original: Polygonal Mind, CC0 1.0 (https://github.com/PolygonalMind/initiative-opensource-release)

Changes from the original release:
- All .tif textures re-saved as .png. Pixels unchanged, including the alpha channel. Embedded Photoshop layer data dropped.
- All 151 .fbx files re-saved so they point to ../Textures/<name>.png. Geometry, names, positions and sizes unchanged (checked against the originals).
- Transparency is set per model: kept on the wreaths, string lights, open present, snow globe, signbook pieces and Lunar Year wearables panels; removed elsewhere, where the texture's alpha channel made solid models see-through.
- Not included in the original release, so still missing: Trash_Alpha (2).png, used by TrashPolka ExteriorPainting, LowerPipe, PoapMachine, StructureLight07 and UpperPipe. Those import as solid.
