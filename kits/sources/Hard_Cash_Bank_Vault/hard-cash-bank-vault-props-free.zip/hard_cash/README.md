# Hard Cash: Bank & Vault Props

14 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| gold_stack | 264 | base_center |
| coin_trays | 728 | base_center |
| brick_pallet | 924 | base_center |
| bankers_lamp | 650 | base_center |
| wait_sign | 516 | base_center |
| managers_desk | 748 | base_center |
| pulled_box | 660 | base_center |
| teller_window | 792 | base_center |
| vault_shelving | 1584 | base_center |
| night_deposit | 440 | world_origin |
| camera_dome | 840 | world_origin |
| vault_door | 3124 | base_center |
| deposit_box_wall | 4664 | base_center |
| rate_board | 528 | world_origin |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
