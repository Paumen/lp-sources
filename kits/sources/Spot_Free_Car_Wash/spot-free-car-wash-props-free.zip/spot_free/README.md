# Spot Free: Car Wash Props

11 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| brush_arch | 4368 | base_center |
| side_brushes | 1968 | base_center |
| mitter_curtain | 1496 | base_center |
| rinse_arch | 1476 | base_center |
| blower_arch | 1060 | base_center |
| conveyor_track | 1236 | base_center |
| vacuum_station | 1260 | base_center |
| wand_bay | 1148 | base_center |
| foam_unit | 674 | base_center |
| price_totem | 1180 | base_center |
| pay_kiosk | 748 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
