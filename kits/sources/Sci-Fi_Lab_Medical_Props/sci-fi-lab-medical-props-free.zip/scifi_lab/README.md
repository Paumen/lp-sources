# Sci-Fi Lab & Medical Props

31 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| specimen_canister | 264 | base_center |
| gas_cylinder | 648 | base_center |
| cryo_rack | 856 | base_center |
| lab_bench | 264 | base_center |
| flask_beaker | 312 | base_center |
| drum | 520 | base_center |
| centrifuge | 636 | base_center |
| autoclave | 548 | base_center |
| petri_stack | 288 | base_center |
| vitals_console | 184 | base_center |
| syringe | 264 | axis |
| cryo_pod | 784 | base_center |
| specimen_jar | 360 | base_center |
| test_tube_rack | 1240 | base_center |
| bunsen_burner | 308 | base_center |
| hot_plate | 308 | base_center |
| fire_extinguisher | 422 | base_center |
| biohazard_bin | 308 | base_center |
| chemical_vat | 792 | base_center |
| lab_stool | 312 | base_center |
| storage_cabinet | 792 | base_center |
| shelf_unit | 264 | base_center |
| analysis_console | 552 | base_center |
| ceiling_lamp | 312 | world_origin |
| hazard_sign | 308 | base_center |
| first_aid_kit | 176 | base_center |
| funnel_stand | 336 | base_center |
| mortar_pestle | 374 | base_center |
| balance_scale | 752 | base_center |
| alembic | 404 | base_center |
| dropper_bottles | 846 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
