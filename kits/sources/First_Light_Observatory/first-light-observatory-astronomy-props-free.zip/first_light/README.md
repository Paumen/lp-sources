# First Light: Observatory & Astronomy Props

5 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| orrery | 14336 | base_center |
| refractor_telescope | 10412 | base_center |
| star_projector | 17912 | base_center |
| armillary_sphere | 6096 | base_center |
| chart_desk | 8000 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).
- `props/<name>.glb` and `props/<name>.fbx`: every prop again as its own
  file, authored at the origin, for dropping a single piece into a scene
  without importing the whole pack. Same geometry and same atlas as
  `pack.glb`; `atlas.png` in this folder serves them too.

## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
