# No Diving: Municipal Pool Props

14 stylized props. Flat-shaded, one shared 1024x1024 atlas.
Per-prop triangle counts are in the table below.

## Scale
1 Blender unit = 1 metre. Built to real-world scale.

## Contents
| Prop | Tris | Pivot |
|---|---|---|
| kickboards | 352 | base_center |
| float_stack | 352 | base_center |
| depth_sign | 220 | world_origin |
| starting_block | 452 | base_center |
| lane_ropes | 6592 | base_center |
| pool_edge_straight | 968 | base_center |
| pool_edge_corner | 1188 | base_center |
| diving_board | 900 | base_center |
| pool_ladder | 848 | base_center |
| bench_hooks | 616 | world_origin |
| pace_clock | 976 | base_center |
| lifeguard_chair | 1320 | base_center |
| swim_sign | 968 | world_origin |
| changing_stall | 748 | base_center |

## Formats
- `pack.glb`: Godot, Three.js, web (Y-up, metres). Recommended.
- `pack.fbx`: Unity/Unreal. In Unity set "Convert Units" on import. In Unreal,
  **disable Generate Lightmap UVs** (this pack uses a single packed UV channel).


## Texturing
One 1024x1024 gradient-ramp atlas, one opaque material + one emissive material.
If props look untextured, ensure `atlas.png` is in the same folder and the material
samples it as Base Color.

## Licence
Base pack: CC0 1.0 (public domain). Use commercially, no attribution required.
